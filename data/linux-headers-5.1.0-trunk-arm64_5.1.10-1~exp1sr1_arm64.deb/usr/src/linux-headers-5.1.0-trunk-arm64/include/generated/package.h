#define LINUX_PACKAGE_ID " Debian 5.1.10-1~exp1sr1"
